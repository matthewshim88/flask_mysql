from flask import Flask, request, redirect, render_template, session, flash
from mysqlconnection import MySQLConnector
import re
app = Flask(__name__)

app.secret_key = "supersecretkey"
mysql = MySQLConnector(app, 'emaildb')
#regex for email
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')


@app.route('/')
def index():
	return render_template('index.html')

@app.route('/submittedEmails', methods=['POST'])
def indexSubmitted():
	query="SELECT * FROM email"
	emailList = mysql.query_db(query)
	return render_template('submittedEmails.html', all_email = emailList)

@app.route('/displayEmails')
def show():
	query = "SELECT *FROM email"
	emailList = mysql.query_db(query)
	return render_template('/submittedEmails.html', all_email = emailList)

@app.route('/submitEmail', methods=['POST'])
def create():
	isValid = True
	if len(request.form['email']) < 1:
		flash('Email cannot be blank!')
		isValid = False
	elif not EMAIL_REGEX.match(request.form['email']):
		flash('Invalid Email Address!')
		isValid = False
	else:
		query = "INSERT INTO email (email) VALUES (:newEmail)"

		data = {
					'newEmail' : request.form['email']
				}
		mysql.query_db(query, data)
	return redirect('/')
	 	


app.run(debug=True)


