from flask import Flask, render_template, request, redirect, session, flash
from mysqlconnection import MySQLConnector
import re

#imports the Bcrypt module
from flask_bcrypt import Bcrypt
app = Flask(__name__)
bcrypt = Bcrypt(app)


app.secret_key = 'secretkeyforsession'

PASSWORD_REGEX = re.compile(r'^(?=.*[A-Z])(?=.*\d)')
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

mysql = MySQLConnector(app, 'loginReg')

@app.route('/')
def index():
	return render_template('index.html')

@app.route('/login', methods=['POST'])
def login():
	isValid = False
	loginEmail = request.form['user']
	loginPass = request.form['password']

	query = "SELECT id, first_name, password FROM users WHERE email=:loginEmail"
	data = {'loginEmail': loginEmail} #using key to reference, don't pass it password, bcrypt does magic
	queryResult= mysql.query_db(query,data)

	#if queryResult finds nothing, it gives empty array '[]', which is 
	#considered 'falsey', this is same as if len(queryResult) == 0
	#Create/send quearyResult in userData so we can edit our own data in login
	if not queryResult:
		flash("Invalid Login Credentials")
		return redirect('/')
	elif bcrypt.check_password_hash(queryResult[0]['password'], loginPass):
		session['user_id'] = queryResult[0]['id']
		return render_template('profilepage.html', userData = queryResult)
	else:
		return redirect('/')


@app.route('/register', methods=['POST'])
def register():
	isValid = True
	if len(request.form['firstname']) < 0:
		isValid = False
	if len(request.form['lastname']) < 0:
		isValid = False
	if len(request.form['email']) < 0:
		isValid = False
	if len(request.form['password']) < 0:
		isValid = False

	if len(request.form['password']) < 8:
		isValid = False
		flash("Password must be at least 8 characters long!")

	if not EMAIL_REGEX.match(request.form['email']):
		isValid = False
		flash("Invalid Email Address!")

	if not PASSWORD_REGEX.match(request.form['password']):
		isValid = False
		flash("Password must contain at least 1 Upper case and one Digit from 0-9")

	if not request.form['firstname'].isalpha() or not request.form['lastname'].isalpha(): 
		isValid = False
		flash("First or Last Name can only be Letters")

	if request.form['password'] != request.form['confirmpass']:
		isValid = False
		flash("Password and Password Confirmation do not Match, Please Re-enter")

	#if everything is valid, store the PW in hash and submit the SQL query
	#we store the form data in variables to make it easier to submit the query
	if isValid == True:
		flash('Registration Successful') #user display to show success
		Fname = request.form['firstname']
		Lname = request.form['lastname']
		Email = request.form['email']
		password = request.form['password']

		#create PW hash with Bcrypt
		pw_hash = bcrypt.generate_password_hash(password)
		#submit SQL query
		query = "INSERT INTO users(first_name, last_name, email, password) VALUES(:firstname, :lastname, :email, :pw_hash)"
		data = {'firstname': Fname, 'lastname': Lname, 'email': Email, 'pw_hash': pw_hash}
		
		mysql.query_db(query, data)
		return redirect('/')
	else:
		return redirect('/')

@app.route('/logout', methods=['POST'])
def logout():
	#deletes session user id
	del session['user_id']
	return redirect('/')

@app.route('/deactivate/<userID>', methods=['POST'])
def deactivate(userID):
	query = "DELETE FROM users WHERE id=:id"
	data={'id': userID}
	mysql.query_db(query,data)
	return redirect('/')

app.run(debug=True)





